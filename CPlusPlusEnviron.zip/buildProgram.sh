#!/bin/bash

g++ consoleGame.cpp
./a.out