#include <iostream>

int main() {}