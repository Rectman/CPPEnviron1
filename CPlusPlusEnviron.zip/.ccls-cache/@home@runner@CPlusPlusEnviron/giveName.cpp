#include <iostream>

int main() {
  std::cout << "\033[2J\033[1;1H";
  std::string name;

  std::cout << "Hi, what's your name?\n";
  std::cin >> name;
  if (name.compare("Daniel") == false || name.compare("daniel") == false) {
    std::cout << "That's a great name, " << name
              << ", you should be proud of yourself.";
  } else {
    std::cout << "That's a stupid fucking name, " << name
              << ", you should be ashamed of yourself.";
  }
}